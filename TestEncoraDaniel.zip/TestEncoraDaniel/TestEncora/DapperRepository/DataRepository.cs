﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Runtime.InteropServices.WindowsRuntime;
using Dapper;

namespace TestEncora
{
    public class DataRepository
    {
        private SqlConnection connection;
        private string stringconection;

        public DataRepository()
        {
            stringconection = ConfigurationManager.ConnectionStrings["TestDbConnectionString"]?.ConnectionString;
            connection = new SqlConnection(stringconection);
        }

        public int Post(DataEntity model)
        {
            int Id;
                var sqlStatement = @"
                    INSERT INTO Properties 
                    (Address
                    ,YearBuilt
                    ,ListPrice
                    ,MonthlyRent
                    ,GrossYield)
                    VALUES (@Address
                    ,@YearBuilt
                    ,@ListPrice
                    ,@MonthlyRent
                    ,@GrossYield);

                    SELECT CAST(SCOPE_IDENTITY() as int)";
                Id = connection.ExecuteScalar<int>(sqlStatement, model);
           
            return Id;
        }


        public IEnumerable<DataEntity> GetAll()
        {
            return connection.Query<DataEntity>(
                "SELECT * " +
                " FROM  Properties p " +
                " ORDER BY IdProperty ");
        }

        public bool DeleteAll()
        {
            connection.OpenAsync();
            var sqlStatement = "DELETE FROM  Properties";
            connection.Execute(sqlStatement);

            return true;
        }
    }
}
