﻿using System;

namespace TestEncora
{
    class Program
    {
        static void Main(string[] args)
        {
           BussinessLogic.InitialLoad();
           Console.ReadLine();
           BussinessLogic.QuickDeleteAndExit();


        }
    }
}
