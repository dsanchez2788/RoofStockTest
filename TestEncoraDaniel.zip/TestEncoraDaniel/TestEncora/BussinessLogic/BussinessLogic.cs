﻿using Newtonsoft.Json;
using System;
using System.Configuration;
using System.IO;
using System.Net;


namespace TestEncora
{
    public static class BussinessLogic
    { 
        static string FeedUrl;
        static DataRepository dboperation = new DataRepository();

        static BussinessLogic()
        {
            FeedUrl = ConfigurationManager.AppSettings["FeedJson"];
        }

        internal static void InitialLoad()
        {
            try
            {
                Console.WriteLine("Getting data, please wait...");
                var GetFeedResult = GetFeed();
                if (GetFeedResult)
                    BuildMenu();
                else
                {
                    Console.WriteLine("Online information could not be possible to retrieve, json file was not saved into the database");
                    Console.WriteLine("Press ENTER to go to menu anyway");
                    Console.ReadLine();
                    BuildMenu();
                }

            }
            catch (Exception ex )
            {
                Console.WriteLine("An error has ocurred: " + ex.Message);
                Console.ReadLine();
            }
        }

        internal static void DeleteAndExit()
        {
            Console.Clear();
            Console.WriteLine("Before exit, do you want to conserve the changes you made? (Y/N)");
            repeat:
            var keepchanges = Convert.ToChar(Console.ReadLine());
            if (keepchanges == 'Y')
                System.Environment.Exit(0);
            else if (keepchanges == 'N')
            {
                dboperation.DeleteAll();
                System.Environment.Exit(0);
            }
            else
            {
                Console.WriteLine("Invalid answer, you typed '" + keepchanges + "' Please choose (Y/N)");
                goto repeat;
            }
        }

        internal static void QuickDeleteAndExit()
        {
            dboperation.DeleteAll();
            System.Environment.Exit(0);
        }


        internal static void BuildMenu()
        {
            try
            {
                Console.Clear();
                byte option;
                Console.WriteLine("MENU");
                Console.WriteLine("1- See all details");
                Console.WriteLine("2- Insert new detail");
                Console.WriteLine("3- Exit");
                Console.WriteLine("Please choose one option by typing the corresponding number");
                tryagain:
                option = Convert.ToByte(Console.ReadLine());

                switch (option)
                {
                    case 1:
                        PrintInformation();
                        break;
                    case 2:
                        InsertRow();
                        break;
                    case 3:
                        {
                            DeleteAndExit();
                            break;
                        }
                    default:
                        {
                            Console.WriteLine("Invalid option. Try again please");
                            goto tryagain;
                        }
                }
               
            }
            catch (Exception ex)
            {
                Console.WriteLine("The following error has ocurred: " + ex.Message);
                Console.WriteLine("Press ENTER to refresh");
                Console.ReadLine();
                BuildMenu();
            }
        }



        internal static void InsertRow() 
        {
            try
            {
                Console.Clear();
                decimal value;
                DataEntity dataEntity = new DataEntity();
                Console.WriteLine("Please type address");
                dataEntity.Address = Console.ReadLine();
                Console.WriteLine("Please type year built");
                dataEntity.YearBuilt = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Please type list price");
                trylistprice:
                if (Decimal.TryParse(Console.ReadLine(), out value))
                    dataEntity.ListPrice = value;
                else
                {
                    Console.WriteLine("The value typed is no correct, let try all again");
                    goto trylistprice;
                }

                Console.WriteLine("Please type monthly rent");
                trymonthlyrent:
                if (Decimal.TryParse(Console.ReadLine(), out value))
                    dataEntity.MonthlyRent = value;
                else
                {
                    Console.WriteLine("The value typed is no correct, let try all again");
                    goto trymonthlyrent;
                }
                dataEntity.GrossYield = (dataEntity.MonthlyRent * 12 / dataEntity.ListPrice) * 100;
                Console.WriteLine("Gross Yield is: " + string.Format("{0:F2}", dataEntity.GrossYield));
                Console.WriteLine("Type ENTER to save the entry");
                repeat:
                if (Console.ReadKey().Key == ConsoleKey.Enter)
                {
                    dboperation.Post(dataEntity);
                    Console.WriteLine("Your entry has been saved succesfully. Press ENTER to return to menu");
                    Console.ReadLine();
                    BuildMenu();
                }
                else
                {
                    Console.WriteLine("Press ENTER to save the entry");
                    goto repeat;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
                Console.WriteLine("Be sure to type values in the correct format, let's try again. Press any key to start again");
                Console.ReadLine();
                InsertRow();
            }
          
        }

        public static bool GetFeed() 
        {
            bool result = false;
            try
            {
                DataEntity dataEntity = new DataEntity();
                string JsonContent = GetJsonInfo(FeedUrl);
                var info = JsonConvert.DeserializeObject<Root>(JsonContent);

                foreach (var item in info.properties)
                {
                    dataEntity.Address = item.address.address1 + ", " + item.address.address2 + ", " +
                    item.address.city + ", " + item.address.country + ", " + item.address.county
                    + ", " + item.address.district + ", " + item.address.state + ", " + item.address.zip
                    + ", " + item.address.zipPlus4;

                    if (item.physical != null)
                        dataEntity.YearBuilt = item.physical.yearBuilt;

                    if (item.financial != null)
                    {
                        dataEntity.ListPrice = Convert.ToDecimal(string.Format("{0:F2}", item.financial.listPrice));
                        dataEntity.MonthlyRent = Convert.ToDecimal(string.Format("{0:F2}", item.financial.monthlyRent));
                        if (item.financial.monthlyRent.HasValue && item.financial.listPrice.HasValue)
                        dataEntity.GrossYield = Convert.ToDecimal(string.Format("{0:F2}", (item.financial.monthlyRent * 12 / item.financial.listPrice) * 100));
                    }

                    dboperation.Post(dataEntity);
                }
                result = true;
            }
            catch (Exception ex)
            {
                result = false;
            }
            return result;
        }

        internal static void PrintInformation()
        {
            Console.Clear();
            var result = dboperation.GetAll();
            foreach (var item in result)
            {
                if (item.YearBuilt != null)
                    Console.WriteLine("Address: " + item.Address);

                if (item.YearBuilt != null)
                    Console.WriteLine("Year Built: " + item.YearBuilt ?? "Not specified");

                if (item.ListPrice != null)
                    Console.WriteLine("List Price: " + Convert.ToDecimal(string.Format("{0:F2}", item.ListPrice) ?? "Not specified"));

                if (item.MonthlyRent != null)
                    Console.WriteLine("Monthly Rent: " + Convert.ToDecimal(string.Format("{0:F2}", item.MonthlyRent) ?? "Not specified"));
                   
                if (item.MonthlyRent.HasValue && item.ListPrice.HasValue)
                        Console.WriteLine("Gross Yield: " + Convert.ToDecimal(string.Format("{0:F2}", (item.MonthlyRent * 12 / item.ListPrice) * 100)) + "%");
                else
                        Console.WriteLine("Gross Yield: Can not be calculated, either the monthly rent or the list price is not provided");
               

                Console.WriteLine("--------------------------------------------------------------------------------------");
            }
            Console.WriteLine("Press ENTER to return to menu");
            Console.ReadLine();
            BuildMenu();
        }

        public static string GetJsonInfo(string url)
        {
            try
            {
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                Stream stream = response.GetResponseStream();
                StreamReader reader = new StreamReader(stream);

                string data = reader.ReadToEnd();

                reader.Close();
                stream.Close();

                return data;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                return "";
            }

        }


    }

}
